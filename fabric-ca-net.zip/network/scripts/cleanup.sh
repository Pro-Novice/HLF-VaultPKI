#!/bin/bash
sudo rm *.json *.tgz *.tar.gz